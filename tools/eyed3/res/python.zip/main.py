import eyed3
eyed3.load(None)
